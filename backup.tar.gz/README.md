ESP8266-MQTT
============

This is NOT A WORKING PROJECT, this is just an idea in the making. To allow me to continue work at my pace, so I decided to upload the code here. 


The Idea of this project is to extend Client and be compatible with the PubClient library for MQTT

PubSubClient target is:
https://github.com/knolleary/pubsubclient/tree/master/PubSubClient


Remember this project is NOT WORKING. IF there is an implementation for the ESP8266 that do MQTT tell me, so I can drop all this and just start using that other.


This  project is the software part of the ESP8266. I am also working on making an interface board called WiFico to ease interfacing the ESP8266 into a breadboard and 5V. Check the hardware at https://github.com/soynerdito/WifIco
